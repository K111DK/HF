/*
 * @Author       : Chivier Humber
 * @Date         : 2021-09-15 21:15:24
 * @LastEditors  : Chivier Humber
 * @LastEditTime : 2021-11-23 16:08:51
 * @Description  : file content
 */
#include "common.h"
#include "memory.h"

namespace virtual_machine_nsp {
    void memory_tp::ReadMemoryFromFile(std::string filename,int beginning_address) {
        // Read from the file
        // TODO->DONE
        int i=0;
        int index = beginning_address;
        int bit=0;
        std::ifstream input_file;
        input_file.open(filename);
        std::string line_command;
        int16_t command_int;
        if (input_file.is_open()) {
            int line_count = std::count(std::istreambuf_iterator<char>(input_file), std::istreambuf_iterator<char>(), '\n');
            input_file.close();
            input_file.open(filename);
                for(i=index;i<index+line_count;++i){
                    input_file >> line_command;
                    command_int=0;
                    if(line_command.find(";")!=std::string::npos){
                        line_command.erase(line_command.find(";"));
                    }
                    for(bit=0;bit<line_command.size();++bit){
                        if(line_command[bit]!='0'){
                            command_int = command_int | (0x8000>>bit);
                        }
                    }
                    this->memory[i] = command_int;
                }
            }
            input_file.close();
        }

    int16_t memory_tp::GetContent(int address) const {
        // get the content
        // TODO->DONE
        return this->memory[address];
    }

    int16_t& memory_tp::operator[](int address) {
        // get the content
        // TODO->DONE
        return this->memory[address];
    }    
}; // virtual machine namespace
